import sqlite3
import pandas as pd

class DatabaseExecutor:
    def __init__(self, connection: sqlite3.Connection):
        self.conn = connection

    def run_query(self, query: str) -> pd.DataFrame:
        cursor = self.conn.cursor()
        cursor.execute(query)
        rows = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]
        return pd.DataFrame(rows, columns=columns)

        