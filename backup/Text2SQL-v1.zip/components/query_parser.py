class QueryParser:
    def __init__(self):
        pass

    def parse(self, question: str) -> str:
        return question.strip()